package leonz2code.org.springBootDemo.springbootin10steps;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootIn10StepsApplicationTests {

	@Test
	void contextLoads() {
	}

}
